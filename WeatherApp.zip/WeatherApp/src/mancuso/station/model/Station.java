package mancuso.station.model;

import java.time.LocalDate;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Station {

    private final StringProperty Station;
    private final StringProperty Temp;
    private final StringProperty Precipitation;
    private final SimpleIntegerProperty Precipitation1;
    private final StringProperty Humidity;
    private final ObjectProperty<LocalDate> selectedDate;

    /**
     * Default constructor.
     */
    public Station() {
        this(null, null);
    }

    /**
     * Constructor with some initial data.
     * 
     * @param Station
     * @param Temp
     */
    public Station(String Station, String Temp) {
        this.Station = new SimpleStringProperty(Station);
        this.Temp = new SimpleStringProperty(Temp);

        // Some initial data for testing.
        this.Precipitation = new SimpleStringProperty("74");
        this.Precipitation1 = new SimpleIntegerProperty(10);
        this.Humidity = new SimpleStringProperty("15");
        this.selectedDate = new SimpleObjectProperty<LocalDate>(LocalDate.of(2017, 11, 9));
    }

    public String getStation() {
        return Station.get();
    }

    public void setStation(String Station) {
        this.Station.set(Station);
    }

    public StringProperty StationProperty() {
        return Station;
    }

    public String getTemp() {
        return Temp.get();
    }

    public void setTemp(String Temp) {
        this.Temp.set(Temp);
    }

    public StringProperty TempProperty() {
        return Temp;
    }

    public String getPrecipitation() {
        return Precipitation.get();
    }

    public void setPrecipitation(String Precipitation) {
        this.Precipitation.set(Precipitation);
    }

    public StringProperty PrecipitationProperty() {
        return Precipitation;
    }

    public int getPrecipitation1() {
        return Precipitation1.get();
    }
    public void setPrecipitation1(int Precipitation1) {
        this.Precipitation1.set(Precipitation1);
    }

    public IntegerProperty Precipitation1Property() {
        return Precipitation1;
    }

    public String getHumidity() {
        return Humidity.get();
    }

    public void setHumidity(String i) {
        this.Humidity.set(i);
    }

    public StringProperty HumidityProperty() {
        return Humidity;
    }

    public LocalDate getselectedDate() {
        return selectedDate.get();
    }

    public void setselectedDate(LocalDate selectedDate) {
        this.selectedDate.set(selectedDate);
    }

    public ObjectProperty<LocalDate> selectedDateProperty() {
        return selectedDate;
    }

	

	
	}
